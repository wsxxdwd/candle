<?php
	if($_POST["user"]){
		$user = $_POST["user"];
		session_start();
		$_SESSION["user"] = $user;
		echo 1;
	}else{
		echo 2;
	}
?>