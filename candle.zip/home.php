<?php
	//链接数据库
	$link = mysql_connect("localhost","root","");
	if(!$link)  
	{  
	   echo "mysql connect failed";
	}	
		//设置数据库编码	
	mysql_query("set names utf8");
	
	//选择数据库
	mysql_select_db("candle",$link); 
	$query = mysql_query("SELECT COUNT(ID) FROM feed");
	$feed_num = mysql_result($query, 0);
	session_start();
	$user = $_SESSION["user"];
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Candle</title> 
	<link rel="stylesheet" href="css/index.css" type="text/css" />
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
	<script type="text/javascript" src="js/jquery.js"></script>
    <script type="text/javascript" src="js/index.js"></script>
</head>
<body>
	
	<div id="main">
		<div id="title">
			<h1><?php 
				if($user == 1){
					echo "猫猫--Candle";
					echo '<script language="javascript">var user = "猫猫";</script>';
				}else if($user == 2){
					echo "汤圆--Flame";
					echo '<script language="javascript">var user = "汤圆";</script>';
				}
				echo '<script language="javascript">var count = '.$feed_num.';</script>';
			?>
			</h1>
			<blockquote>I am the flame and you are the candle that holds my light.</blockquote>
			<h4 id="count">我们已经发布了<?php echo $feed_num;?>句话!</h4>
		</div>
		<div id="foo">
		<table class="table" id="feedList">
				<tbody>
			<?php 
				$sql = mysql_query("SELECT * FROM feed ORDER BY ID DESC");
				while($row = mysql_fetch_array($sql)){
					$content = $row['content'];
					$motion = $row['motion'];
					$time = $row['time'];
					$post_user = $row['user_id']==1?'猫猫':'汤圆';
					switch($motion){
						case "淡定":
						case "想念":
							$type = "info";
							break;
						case "感动":
						case "高兴":
						case "期待":
							$type = "success";
							break;
						case "生气":
						case "痛苦":
							$type = "error";
							break;
						case "失望":
						case "难过":
							$type = "warning";
							break;
					}
					echo '<tr class="'.$type.'"><td>'.$post_user." ".$motion." 地说: <b>".$content.'</b>  <i>发布于'.$time.'</i></td></tr>';
				}
			?>
			</tbody>
		</table>
		</div>
		<form>
			<select id="motion">
				<option value="淡定">淡定</option>
				<option value="高兴">高兴</option>
				<option value="生气">生气</option>
				<option value="难过">难过</option>
				<option value="失望">失望</option>
				<option value="想念">想念</option>
				<option value="感动">感动</option>
				<option value="期待">期待</option>
				<option value="痛苦">痛苦</option>
			</select>
			<textarea id="content"></textarea>
			<input type="button" id="post" value="发送" class="btn-block btn-primary"></input>
		</form>
	</div>
</body>