<?php
session_start();
if(isset($_SESSION["user"])){
  //注销返回首页时 终结SESSION["id"]
  unset($_SESSION["user"]);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Candle</title> 
	<link rel="stylesheet" href="css/bootstrap.css" type="text/css" />
	<script type="text/javascript" src="js/jquery.js"></script>
</head>
<body style="padding:10%;">
	<h1>Candle</h1>
	<input type="button" class="btn btn-block btn-primary" id="user1" value="猫猫"></input>
	<input type="button" class="btn btn-block" id="user2" value="汤圆"></input>
	<script language="javascript">
		$("#user1").bind("click",function(){
			$.ajax({
				type:"post",
				url:"./login.php",
				data:"&user="+1,
				success:
					function(returnKey){
						if(returnKey == 1){
							window.location.href = "home.php";
						}else{
							alert("猫猫登录失败");
						}
					}
			});
		});
		$("#user2").bind("click",function(){
			$.ajax({
				type:"post",
				url:"./login.php",
				data:"&user="+2,
				success:
					function(returnKey){
						if(returnKey == 1){
							window.location.href = "home.php";
						}else{
							alert("汤圆登录失败");
						}
					}
			});
		});
	</script>
</body>