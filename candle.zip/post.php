<?php
    //php环境编码
    header("Content-Type:text/html;charset=utf-8");

    //链接数据库
    $link = mysql_connect("localhost","root","");
    if(!$link)  
    {  
       echo "mysql connect failed";
    }	

    //设置数据库编码	
    mysql_query("set names utf8");
    
    //选择数据库
    mysql_select_db("candle",$link); 
	
	session_start();
	$user = $_SESSION["user"];
	
	if($_POST["motion"]&&$_POST["content"]&&$_POST["time"]){
		$c = $_POST["content"];
		$m = $_POST["motion"];
		$t = $_POST["time"];
		
		if(mysql_query("INSERT INTO feed (content,motion,user,time) VALUES ('$c','$m','$user','$t')")){
		  echo 1;
		}else{
			echo 2;
		}
	}
?>